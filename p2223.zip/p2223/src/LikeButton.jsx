import { useState } from "react";

export default function Likebutton(){
//use only inside the function component
// inside one function component we can create multiple state components
    let [isLike, setIsLike] = useState(false);
    let [count , setCount]= useState(0);

    let toggleLike = ()=>{
        setIsLike (!isLike);
        setCount (count+1);
    }

    let clicked=()=>{
        console.log("Clicked......")
    }

    let likeStyle = {color: "red"}
    return(
        <>
        <p onClick={toggleLike}>
            {
            isLike? (<i className="fa-sharp fa-solid fa-heart" style={likeStyle}></i>):
            (<i className="fa-regular fa-heart"></i>)
        }   
        </p>
        <p>Count = {count}</p>
        </>
    );
}