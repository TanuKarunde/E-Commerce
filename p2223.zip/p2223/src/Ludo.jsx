import { useState } from "react"

export default function LudoGame() {
    let [moves, setMoves] = useState({ blue: 0, yellow: 0, red: 0, green: 0 });
    let [arr ,setArr] = useState(["moves"]);
    // ....spread and create copy of object and then render it
    // callback in updater function
    let countB = () => {
        setMoves((prevMoves) => {
            return { ...prevMoves, blue: prevMoves.blue + 1 };
        });
        setArr((preArr)=>{
            return [...preArr, " Next move "];
        } )
    }
    let countY = () => {
        setMoves((prevMoves) => {
            return { ...prevMoves, yellow: prevMoves.yellow + 1 };
        });
    }
    let countR = () => {
        setMoves((prevMoves) => {
            return { ...prevMoves, red: prevMoves.red + 1 };
        });
    }
    let countG = () => {
        setMoves((prevMoves) => {
            return { ...prevMoves, green: prevMoves.green + 1 };
        });
    }
    return (
        <div className="board">
            <p>{arr}</p>
            <p>Blue = {moves.blue}</p>
            <button style={{ backgroundColor: "blue", color: "black" }} onClick={countB}>+1</button>
            <p>Yellow = {moves.yellow} </p>
            <button style={{ backgroundColor: "yellow", color: "black" }} onClick={countY}>+1</button>
            <p>Red = {moves.red} </p>
            <button style={{ backgroundColor: "red", color: "black" }} onClick={countR}>+1</button>
            <p>Green = {moves.green} </p>
            <button style={{ backgroundColor: "green", color: "black" }} onClick={countG}>+1</button>
        </div>
    )
}