export default function Counter(){
    let count =0;

    function isCount(){
        count+= 1;
        console.log(count);
    }

    return(
        <>
        <h3>Count = {count}</h3>
        <button onClick={isCount}>Increase Count</button>
        </>
    );
}