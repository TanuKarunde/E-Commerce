import './App.css'
import Counter from './Counter'
import Effect from './Effect'
import Likebutton from './LikeButton'
import LudoGame from './Ludo'


function App() {
  

  return (
    <>
      <h3>States in React</h3>
      <Likebutton/>
      <LudoGame/>
    </>
  )
}

export default App
